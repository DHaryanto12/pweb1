<aside class="container">
<nav class="nav justify-content-center">
    <a class="nav-link active" href="?menu=index">Beranda</a>
    <a class="nav-link active" href="?menu=about">Tentang saya</a>
    <a class="nav-link active" href="?menu=portfolio">Portofolio</a>
    <a class="nav-link active" href="?menu=blog">Blog</a>
    <a class="nav-link active" href="?menu=contact">Kontak</a>
    </nav>
</aside>